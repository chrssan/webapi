/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.gbank.services;

import com.mycompany.gbank.models.Account;
import com.mycompany.gbank.databases.Database;
import java.util.List;

/**
 *
 * @author Zuha Ansari
 */
public class AccountServices {
    Database d = new Database();
    private List<Account> list = d.getAccountDB();
    
    public List<Account> getAllAccounts(){
        return list;
    }

    public Account getAccount(int id){
        return list.get(id-1);
    }
    public Account createAccount(Account a){
        a.setAccID(list.size() +1);
        list.add(a);
        System.out.println("201 - resource created with path: /Accounts/"  + String.valueOf(a.getAccID()));
        return a;
    }
}
