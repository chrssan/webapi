/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.gbank.services;

import com.mycompany.gbank.models.Account;
import com.mycompany.gbank.models.Transactions;
import com.mycompany.gbank.databases.Database;
import java.util.List;

/**
 *
 * @author Zuha Ansari
 */
public class TransactionServices {
     Database d = new Database();
    private List<Transactions> tlist = d.getTransactionDB();
    private List<Account> alist = d.getAccountDB();
    
    public List<Transactions> getAllTransactions(){
        return tlist;
    }
    public List<Transactions> getAllTransactionsByAccounts(int AccID){
        return alist.get(AccID-1).getTransactions();
    }
    public Transactions getTransactionID(int id){
        return tlist.get(id-1);
    }
    public Transactions createTransaction(Transactions t){
        t.setTranID(tlist.size() +1);
        tlist.add(t);
        System.out.println("201 - resource created with path: /Transactions/"  + String.valueOf(t.getTranID()));
        return t;
    }
}
