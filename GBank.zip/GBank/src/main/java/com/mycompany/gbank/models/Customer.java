/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.gbank.models;

import java.util.List;

/**
 *
 * @author Zuha Ansari
 */
public class Customer {
    private String Name;
    private String Address;
    private String Email;
    private int ID;
    private List<Account> Accounts;
    public Customer(){}
    public Customer(int ID, String Name, String Address, String Email, List<Account> Accounts){
        
        this.ID = ID;
        this.Name = Name;
        this.Address=Address;
        this.Email=Email;
        this.Accounts=Accounts;
    }

    public int getID() {
        return ID;
    }

    public List<Account> getAccounts() {
        return Accounts;
    }

    public void setAccounts(List<Account> Accounts) {
        this.Accounts = Accounts;
    }

    public void setID(int ID) {
        this.ID = ID;
    }
    
    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }
   
}
