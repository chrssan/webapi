/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.gbank.models;

import java.util.List;

/**
 *
 * @author Zuha Ansari
 */
public class Account {

    private int AccID;
    private String SortCode;
    private Double Balance;
    private String AccType;
    private List<Transactions> Transactions;

    public Account() {
    }

    public Account(int AccID, String SortCode, Double Balance, String AccType, List<Transactions> Transactions) {
        this.AccID = AccID;
        this.SortCode = SortCode;
        this.Balance = Balance;
        this.AccType = AccType;
        this.Transactions = Transactions;
    }

    public List<Transactions> getTransactions() {
        return Transactions;
    }

    public void setTransactions(List<Transactions> Transactions) {
        this.Transactions = Transactions;
    }

    public String getSortCode() {
        return SortCode;
    }

    public int getAccID() {
        return AccID;
    }

    public void setAccID(int AccID) {
        this.AccID = AccID;
    }

    public String getAccType() {
        return AccType;
    }

    public void setAccType(String AccType) {
        this.AccType = AccType;
    }

    public void setSortCode(String SortCode) {
        this.SortCode = SortCode;
    }

    public Double getBalance() {
        return Balance;
    }

    public void setBalance(Double Balance) {
        this.Balance = Balance;
    }

}
