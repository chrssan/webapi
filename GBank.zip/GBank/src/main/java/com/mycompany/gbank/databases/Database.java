/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.gbank.databases;
import com.mycompany.gbank.models.Account;
import com.mycompany.gbank.models.Customer;
import com.mycompany.gbank.models.Transactions;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Zuha Ansari
 */
public class Database {
    
public static List<Customer> customerDB = new ArrayList<>();
public static List<Transactions> transactionDB = new ArrayList<>();
public static List<Account> accountDB = new ArrayList<>();
public static boolean init = true;

    public Database() {
        if (init){
    
        //create Accounts
        Account a1 = new Account (1, "218934265", 3246.00, "Current",transactionDB);
        Account a2 = new Account (2, "9923572", 6255.99, "Saving", transactionDB);
        Account a3 = new Account (3, "084573", 1092.40, "Saving", transactionDB);
        Account a4 = new Account (4, "383475", 8523.80, "Saving", transactionDB);
        Account a5 = new Account (5, "23324", 31872.95, "Current", transactionDB);
        
        accountDB.add(a1);
        accountDB.add(a2);
        accountDB.add(a3);
        accountDB.add(a4);
        accountDB.add(a5);
        
        //create customers
        Customer c1 = new Customer (1,"Gurpreet Kumar", "68 Apt, Park Road, Dublin, Ireland", "gpku@gmail.com", accountDB);
        Customer c2 = new Customer (2,"Jules Matthew", "632 Apt, Park Road, Dublin, Ireland", "jmatthew@gmail.com", accountDB);
        Customer c3 = new Customer (3,"Ashley Kingsley", "90 Apt, Park Road, Dublin, Ireland", "ashking@gmail.com", accountDB);
        Customer c4 = new Customer (4,"Lauren Plants", "78, Park Drive, Galway, Ireland", "ashishkumar@gmail.com", accountDB);
        Customer c5 = new Customer (5,"Penny Poser", "90 Peony House, Adelaide Road, Dublin, Ireland", "penny@gmail.com", accountDB);
        
        customerDB.add(c1);
        customerDB.add(c2);
        customerDB.add(c3);
        customerDB.add(c4);
        customerDB.add(c5);
        init=false;
       
        //created transactions 
        Transactions t1 = new Transactions (1, "Credit", "09/10/2019", "Rent", 1090.90);
        Transactions t2 = new Transactions (2, "Debit", "09/10/2019", "Wages", 2002.09);
        Transactions t3 = new Transactions (3, "Credit", "09/10/2019", "Electricity", 50.60);
        Transactions t4 = new Transactions (4,"Debit", "09/10/2019", "Sarah Lunch money", 20);
        Transactions t5 = new Transactions (5,"Credit", "09/10/2019", "Danah birthday", 27);
        
        transactionDB.add(t1);
        transactionDB.add(t2);
        transactionDB.add(t3);
        transactionDB.add(t4);
        transactionDB.add(t5);
        }
    }
    
        
    public static List<Account> getAccountDB() {
        return accountDB;
    }
    
    public static List<Customer> getCustomerDB() {
        return customerDB;
    }
        
    public static List<Transactions> getTransactionDB() {
        return transactionDB;
    }
    
}
