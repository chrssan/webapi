/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.gbank.services;

import com.mycompany.gbank.models.Account;
import com.mycompany.gbank.models.Customer;
import com.mycompany.gbank.databases.Database;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 *
 * @author Zuha Ansari
 */
public class CustomerServices {
     Database d = new Database();
    private List<Customer> list = d.getCustomerDB();
    
    public List<Customer> getAllCustomers(){
        return list;
    }

    public Customer getCustomer(int id){
        return list.get(id-1);
    }
    public Customer createCustomer(Customer c){
        List<Account> alist = new ArrayList();
        Account a = new Account();
        a.setAccID((int) Math.random());
        a.setAccType("Current");
        a.setBalance(Double.NaN);
        a.setSortCode(UUID.randomUUID().toString());
        a.setTransactions(null); 
        alist.add(a);
        c.setAccounts(alist);
        c.setID(list.size() +1);
        list.add(c);
        System.out.println("201 - resource created with path: /Customers/"  + String.valueOf(c.getID()));
        return c;
    }
}
