/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.gbank.resources;

import com.mycompany.gbank.models.Transactions;
import com.mycompany.gbank.services.TransactionServices;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Zuha Ansari
 */
@Path("/Transactions")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)

public class TransactionResources {
    private TransactionServices transactionServices = new TransactionServices();
    
    @GET
    public List<Transactions> getTransactions(@PathParam("AccountID") int id){
        System.out.println("getAllTransactiosForAccount..."+id);
        return transactionServices.getAllTransactions();
    }
    @GET
    @Path("/{tranId}")
    public Transactions getTransaction(@PathParam("tranId") int id){
        System.out.println("getTransactionById..."+id);
        return transactionServices.getTransactionID(id);
    }
    @POST
    public Transactions createTransactions(Transactions t){
        return transactionServices.createTransaction(t);
    }
    
}
